// localStorage module
