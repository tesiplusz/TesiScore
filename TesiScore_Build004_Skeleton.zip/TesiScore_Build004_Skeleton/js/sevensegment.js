// seven segment renderer
