# Architecture

Modules:
- settings
- storage
- timer
- scoreboard
- sevensegment
- keyboard
- fullscreen
